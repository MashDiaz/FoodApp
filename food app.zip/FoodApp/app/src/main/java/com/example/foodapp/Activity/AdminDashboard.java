package com.example.foodapp.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.foodapp.R;
import com.example.foodapp.Activity.DBHelper;
import com.google.android.gms.maps.model.LatLng;

public class AdminDashboard extends AppCompatActivity {

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.passAdminLoginpass), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Handle adding items
        Button btnadminAddItems = findViewById(R.id.btnadminAddItems);
        btnadminAddItems.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboard.this, AdminAddItemsSec.class);
            startActivityForResult(intent, 100);  // Request code for adding items
        });

        // Handle adding location
        Button btnAddLocation = findViewById(R.id.btnAddLocation);
        btnAddLocation.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboard.this, MapActivity.class);
            startActivityForResult(intent, 200);  // Using a request code of 200
        });

        // Handle managing users
        Button btnMngUsers = findViewById(R.id.btnMngUsers);
        btnMngUsers.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboard.this, ManageUsersActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK) {
            String itemName = data.getStringExtra("itemName");
            double itemPrice = data.getDoubleExtra("itemPrice", 0.0);
            boolean isBestDeal = data.getBooleanExtra("isBestDeal", false);

            if (isBestDeal) {
                dbHelper.addBestDeal(itemName, itemPrice);
                Toast.makeText(this, "Item added to Best Deals!", Toast.LENGTH_SHORT).show();
            }
        }

        if (requestCode == 200 && resultCode == RESULT_OK) {
            double latitude = data.getDoubleExtra("latitude", 0.0);
            double longitude = data.getDoubleExtra("longitude", 0.0);

            saveLocationToDatabase(new LatLng(latitude, longitude), "Selected Location");
            Toast.makeText(this, "Location saved successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveLocationToDatabase(LatLng latLng, String placeName) {
        // Your SQLite saving logic here
    }
}
